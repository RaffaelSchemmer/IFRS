package com.ifrs.app

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.gson.JsonParser
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var btnWeather: Button
    private lateinit var imgWeather: ImageView
    private lateinit var rootLayout: ConstraintLayout
    private lateinit var containerList: LinearLayout

    private val apiKey = "fbd2f9ebe81059a86e30de49d62d6b7d"
    private val poaLat = -30.0346   // Latitude de Porto Alegre
    private val poaLon = -51.2177   // Longitude de Porto Alegre

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        btnWeather = findViewById(R.id.btnWeather)
        imgWeather = findViewById(R.id.imgWeather)
        rootLayout = findViewById(R.id.rootLayout)
        containerList = findViewById(R.id.containerList)

        btnWeather.setOnClickListener {
            fetchWeather(poaLat, poaLon)
        }
    }

    private fun fetchWeather(lat: Double, lon: Double) {

        val url =
            "https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric&lang=pt_br"

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Erro: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (body != null) {

                    val json = JsonParser.parseString(body).asJsonObject
                    val temp = json.getAsJsonObject("main").get("temp").asDouble
                    val condition = json.getAsJsonArray("weather")[0].asJsonObject.get("description").asString
                    val city = json.get("name").asString
                    val country = json.getAsJsonObject("sys").get("country").asString

                    runOnUiThread {
                        // Alterar imagem e cor de fundo do layout
                        when {
                            condition.contains("chuva", true) -> {
                                imgWeather.setImageResource(R.drawable.rain)
                                rootLayout.setBackgroundColor(Color.parseColor("#D6EAF8"))
                            }
                            condition.contains("nuvem", true) -> {
                                imgWeather.setImageResource(R.drawable.cloud)
                                rootLayout.setBackgroundColor(Color.parseColor("#E5E7E9"))
                            }
                            condition.contains("céu limpo", true) -> {
                                imgWeather.setImageResource(R.drawable.sun)
                                rootLayout.setBackgroundColor(Color.parseColor("#FEF9E7"))
                            }
                            else -> {
                                imgWeather.setImageResource(R.drawable.weather)
                                rootLayout.setBackgroundColor(Color.parseColor("#F5EEF8"))
                            }
                        }

                        // Criar TextView para city - country - temp
                        val tv = TextView(this@MainActivity).apply {
                            text = "$city - $country - ${temp}°C"
                            textSize = 24f
                            setPadding(16, 32, 16, 16)
                            setTextColor(Color.parseColor("#79fa86"))
                            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                        }

                        // Adicionar no topo do container
                        containerList.addView(tv, 0)
                    }
                }
            }
        })
    }
}
