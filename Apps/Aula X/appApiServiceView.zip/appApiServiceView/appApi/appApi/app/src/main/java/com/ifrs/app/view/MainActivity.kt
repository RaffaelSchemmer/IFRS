

package com.ifrs.app.view
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.ifrs.app.R
import com.ifrs.app.dto.WeatherDTO
import com.ifrs.app.service.WeatherService

class MainActivity : AppCompatActivity() {

    private lateinit var btnWeather: Button
    private lateinit var imgWeather: ImageView
    private lateinit var rootLayout: ConstraintLayout
    private lateinit var containerList: LinearLayout
    private lateinit var weatherService: WeatherService

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        btnWeather = findViewById(R.id.btnWeather)
        imgWeather = findViewById(R.id.imgWeather)
        rootLayout = findViewById(R.id.rootLayout)
        containerList = findViewById(R.id.containerList)

        weatherService = WeatherService()

        btnWeather.setOnClickListener {

            weatherService.fetchWeather { weatherDTO ->
                if (weatherDTO != null) {
                    runOnUiThread { updateUI(weatherDTO) }
                } else {
                    runOnUiThread {
                        Toast.makeText(this, "Não foi possível obter o clima", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            }
        }
    }

    private fun updateUI(weatherDTO : WeatherDTO){

        when {
            weatherDTO.condition?.contains("chuva", true) == true -> {
                imgWeather.setImageResource(R.drawable.rain)
                rootLayout.setBackgroundColor(Color.parseColor("#D6EAF8"))
            }
            weatherDTO.condition?.contains("nuvem", true) == true -> {
                imgWeather.setImageResource(R.drawable.cloud)
                rootLayout.setBackgroundColor(Color.parseColor("#E5E7E9"))
            }
            weatherDTO.condition?.contains("céu limpo", true) == true -> {
                imgWeather.setImageResource(R.drawable.sun)
                rootLayout.setBackgroundColor(Color.parseColor("#FEF9E7"))
            }
            else -> {
                imgWeather.setImageResource(R.drawable.weather)
                rootLayout.setBackgroundColor(Color.parseColor("#F5EEF8"))
            }
        }
            // Cria TextView com as informações do clima
                val tv = TextView(this).apply {
                text = "${weatherDTO.city ?: "-"} - ${weatherDTO.country ?: "-"} - ${weatherDTO.temperature ?: "-"}°C"
                textSize = 24f
                setPadding(16, 32, 16, 16)
                setTextColor(Color.parseColor("#79fa86"))
                textAlignment = TextView.TEXT_ALIGNMENT_CENTER
            }

            // Adiciona no topo do container
            containerList.addView(tv, 0)

        }
    }

