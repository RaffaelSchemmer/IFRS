package com.ifrs.app.service

import android.graphics.Color
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import com.google.gson.JsonParser
import com.ifrs.app.R
import com.ifrs.app.dto.WeatherDTO
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class WeatherService {

    private val apiKey = "fbd2f9ebe81059a86e30de49d62d6b7d"
    private val poaLat = -30.0346   // Latitude de Porto Alegre
    private val poaLon = -51.2177   // Longitude de Porto Alegre

    public fun fetchWeather(callback: (WeatherDTO?) -> Unit) {

        val url = "https://api.openweathermap.org/data/2.5/weather?" +
                "lat=$poaLat" +
                "&lon=$poaLon" +
                "&appid=$apiKey" +
                "&units=metric" +
                "&lang=pt_br"

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                Log.e("WeatherService", "Erro ao buscar clima: ${e.message}")
                callback(null) // Retorna null para indicar falha
            }

            override fun onResponse(call: Call, response: Response)
            {

                val body = response.body?.string()
                if (body != null) {

                    try {

                        val json = JsonParser.parseString(body).asJsonObject

                        val temp = json.getAsJsonObject("main")?.get("temp")?.asDouble
                        val condition =
                            json.getAsJsonArray("weather")[0].asJsonObject?.get("description")?.asString
                        val city = json.get("name")?.asString
                        val country = json.getAsJsonObject("sys")?.get("country")?.asString

                        val WeatherDTO = WeatherDTO(

                            temperature = temp,
                            city = city,
                            country = country,
                            condition = condition
                        )

                        callback(WeatherDTO)
                    }
                    catch (e: Exception)
                    {
                        Log.e("WeatherService", "Erro ao processar JSON: ${e.message}")
                        callback(null)
                    }
                }
                else{
                    callback(null)
                }
            }
        })
    }
}