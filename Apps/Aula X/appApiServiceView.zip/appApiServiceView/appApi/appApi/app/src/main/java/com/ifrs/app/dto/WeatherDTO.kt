package com.ifrs.app.dto

data class WeatherDTO (
    val temperature: Double?,
    val city: String?,
    val country: String?,
    val condition:String?
)

