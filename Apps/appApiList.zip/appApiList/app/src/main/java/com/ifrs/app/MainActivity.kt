package com.ifrs.app

// Novas Bibliotecas
import com.google.gson.JsonParser
import okhttp3.*

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var btnWeather: Button
    private lateinit var tvTemperature: TextView
    private lateinit var tvCondition: TextView
    private lateinit var imgWeather: ImageView
    private lateinit var rootLayout: ConstraintLayout
    private lateinit var weatherListLayout: LinearLayout

    private val apiKey = "fbd2f9ebe81059a86e30de49d62d6b7d"

    private val poaLat = -9.974   // Latitude de Porto Alegre
    private val poaLon = -67.8076   // Longitude de Porto Alegre

    //private val poaLat = -30.0346   // Latitude de Porto Alegre
    //private val poaLon = -51.2177   // Longitude de Porto Alegre

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        btnWeather = findViewById(R.id.btnWeather)
        tvTemperature = findViewById(R.id.tvTemp)
        tvCondition = findViewById(R.id.tvCondition)
        imgWeather = findViewById(R.id.imgWeather)
        rootLayout = findViewById(R.id.rootLayout)
        weatherListLayout = findViewById(R.id.weatherListLayout)

        btnWeather.setOnClickListener {
            fetchWeather(poaLat, poaLon)
        }
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        val url =
            "https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric&lang=pt_br"
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Link Indisponivel", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (body != null) {
                    val json = JsonParser.parseString(body).asJsonObject

                    val temp = json.getAsJsonObject("main").get("temp").asDouble
                    val condition = json.getAsJsonArray("weather")[0].asJsonObject.get("description").asString


                    runOnUiThread {

                        tvCondition.text = "$condition"
                        tvTemperature.text = "%.0f °C".format(temp)

                        when {
                            condition.contains("chuva", true) -> {
                                imgWeather.setImageResource(R.drawable.rain)
                            }
                            condition.contains("nuvem", true) -> {
                                imgWeather.setImageResource(R.drawable.cloud)
                            }
                            condition.contains("céu limpo", true) -> {
                                imgWeather.setImageResource(R.drawable.sun)
                            }
                            else -> {
                                imgWeather.setImageResource(R.drawable.weather)
                            }
                        }

                        val cidade = json.get("name").asString
                        val entryCidade = "Cidade: $cidade - BR"
                        val entryTemp = "Temperatura: %.0f°C".format(temp)


                        val itemLayout = LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(0, 16, 0, 16)
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ).apply {
                                setMargins(0, 8, 0, 8)
                            }
                            gravity = Gravity.CENTER_HORIZONTAL
                        }


                        val tvCidade = TextView(this@MainActivity).apply {
                            text = entryCidade
                            textSize = 16f
                            setTextColor(resources.getColor(android.R.color.black))
                            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                        }


                        val tvTemp = TextView(this@MainActivity).apply {
                            text = entryTemp
                            textSize = 16f
                            setTextColor(resources.getColor(android.R.color.black))
                            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                        }

                        itemLayout.addView(tvCidade)
                        itemLayout.addView(tvTemp)

                        // Adiciona itemLayout à lista
                        weatherListLayout.addView(itemLayout, 0)


                    }
                }
            }
        })
    }
}
