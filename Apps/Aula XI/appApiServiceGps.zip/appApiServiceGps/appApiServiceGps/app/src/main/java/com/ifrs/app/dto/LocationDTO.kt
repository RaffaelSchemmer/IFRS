package com.ifrs.app.dto

data class LocationDTO(
    val latitude: Double,
    val longitude: Double
)
