package com.ifrs.app.service

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.* // Biblioteca do Google para acessar localização
import com.ifrs.app.dto.LocationDTO // Classe DTO que guarda latitude e longitude

// Classe auxiliar responsável por obter a localização atual do dispositivo (GPS)
class GpsService(private val activity: Activity) {

    // Cliente que fornece acesso ao serviço de localização do Google (GPS + rede)
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(activity)

    // Código usado para identificar a solicitação de permissão de localização
    private val LOCATION_PERMISSION_REQUEST = 1000

    /**
     * Obtém a localização atual (latitude e longitude)
     * - onLocationReceived é uma função de callback que recebe o resultado
     */
    fun getLocation(onLocationReceived: (LocationDTO) -> Unit) {

        // Verifica se a permissão de localização foi concedida
        if (ActivityCompat.checkSelfPermission(
                activity,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Caso não tenha permissão, solicita ao usuário
            ActivityCompat.requestPermissions(
                activity,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
            // Sai da função (espera o usuário responder à solicitação)
            return
        }

        // Tenta obter a última localização conhecida do dispositivo
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    // Se conseguiu pegar a localização, cria o DTO
                    val dto = LocationDTO(location.latitude, location.longitude)

                    // Executa a função recebida por parâmetro, entregando o DTO
                    onLocationReceived(dto)
                } else {
                    // Caso a localização venha nula, lança uma exceção
                    throw IllegalStateException("Não foi possível obter a localização")
                }
            }
            .addOnFailureListener { e ->
                // Caso ocorra algum erro (ex: GPS desligado, falha do serviço)
                throw e
            }
    }
}
