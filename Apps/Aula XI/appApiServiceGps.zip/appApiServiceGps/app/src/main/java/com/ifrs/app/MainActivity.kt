package com.ifrs.app
import com.ifrs.app.service.GpsService

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnGps: Button

    private lateinit var gpsService: GpsService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        btnGps = findViewById(R.id.btnGps)

        gpsService = GpsService(this)

        btnGps.setOnClickListener {

            // Aqui chamamos o GPS, e só quando estiver pronto listamos na Log
            gpsService.getLocation { dto ->
                Log.d("GPS", "Latitude: ${dto.latitude}, Longitude: ${dto.longitude}")
            }
        }
    }
}
