package com.ifrs.app

import android.media.MediaPlayer
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    // Declaração das variáveis dos elementos visuais
    private lateinit var textViewContador: TextView
    private lateinit var textViewTimer: TextView
    private lateinit var imageViewTomato: ImageView
    private lateinit var imageViewSair: ImageView

    // Declaração das variáveis do programa
    private var contador = 1500
    private var temp = 0
    private var contadorJob: Job = Job()
    private lateinit var vibrator: Vibrator
    private var mediaPlayer: MediaPlayer? = null

    /** Confirmação com Sim/Não */
    fun funcaoSair(context: Context, title: String, message: String, onConfirm: () -> Unit) {
        AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("Sim") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
            .setNegativeButton("Não") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // Método é chamado toda vez que o app abrir
    override fun onCreate(savedInstanceState: Bundle?)
    {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity) // seu XML do layout

        // Aqui eu capturo o manipulador do componente visual
        textViewContador = findViewById(R.id.textViewContador)
        textViewTimer = findViewById(R.id.textViewTimer)
        imageViewTomato = findViewById(R.id.imageViewTomato)
        imageViewSair = findViewById(R.id.imageViewSair)

        // Aqui eu chamo o Vibrator
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        // Aqui eu capturo o click do tomate
        imageViewTomato.setOnClickListener {

            if(imageViewTomato.isEnabled == true)
            {

                imageViewTomato.isEnabled = false
                contadorJob = lifecycleScope.launch()
                {

                    while (true) {

                        // Decrementa o contador
                        contador--

                        // Atualiza o TextView com o valor atual do contador
                        textViewTimer.text = formatarTempo(contador)

                        // Pausa a execução da corrotina por 1 segundo
                        delay(1000)

                        // Implementar as condições de feedback
                        // Passou 5 minutos (vibre celular)
                        if(contador % 300 == 0)
                        {
                            vibrarLongo()
                        }

                        // Chegou a 5 minutos (toca som)
                        if(contador == 300)
                        {
                            tocarSom(R.raw.despertar)
                        }

                        // Terminou o Pomodoro
                        if(contador == 0)
                        {
                            // 1. Tocar o som
                            tocarSom(R.raw.acabar)

                            // 2. Voltar o timer para 25:00 (1500)
                            contador = 1500
                            textViewTimer.text = formatarTempo(contador)

                            // 3. Incrementar o contador de Pomodoro em +1
                            temp = textViewContador.text.toString().toInt() + 1
                            textViewContador.text = temp.toString()

                            // 4. Liberar o botão para um novo clique
                            imageViewTomato.isEnabled = true

                            // 5. Parar o laço de repetição
                            break
                        }
                    }
                }
            }
        }

        // Aqui eu capturo o click do sair
        imageViewSair.setOnClickListener {
            funcaoSair(this,"AppPomodoro","Deseja Fechar o Programa?") {}
        }
    }

    // Função que formata o tempo (de segundos para MM:SS
    fun formatarTempo(segundos: Int): String {
        val min = segundos / 60
        val sec = segundos % 60
        return String.format("%02d:%02d",min,sec)
    }

    // Função que faz o celular vibrar
    private fun vibrarLongo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    // Função que faz o telefone tocar som
    private fun tocarSom(resId: Int) {
        // Libera o MediaPlayer anterior
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resId)
        mediaPlayer?.start()
    }
}