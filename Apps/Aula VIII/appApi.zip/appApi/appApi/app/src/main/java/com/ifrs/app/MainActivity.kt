package com.ifrs.app

import com.google.gson.JsonParser
import okhttp3.*

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity()
{

    private lateinit var buttonApi: Button
    private lateinit var imageViewPrevisao: ImageView
    private lateinit var textViewCondicao : TextView
    private lateinit var textViewTemperatura : TextView

    private var poalat = -30.0346
    private var poalon = -51.2177

    // Método é chamado toda vez que o app abrir
    override fun onCreate(savedInstanceState: Bundle?)
    {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity) // seu XML do layout

        buttonApi = findViewById(R.id.buttonApi)
        imageViewPrevisao = findViewById(R.id.imageViewPrevisao)
        textViewCondicao = findViewById(R.id.textViewCondicao)
        textViewTemperatura = findViewById(R.id.textViewTemperatura)

        buttonApi.setOnClickListener {
            fetchWeather(poalat, poalon)
        }

    }

    fun fetchWeather(poaLat:Double, poaLon:Double)
    {

        // Fazer a chamada da API

        // Capturar o retorno e fazer o parse do JSON

    }

}