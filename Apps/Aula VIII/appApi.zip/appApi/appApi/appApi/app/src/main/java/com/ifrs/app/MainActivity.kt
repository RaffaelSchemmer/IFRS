package com.ifrs.app

import com.google.gson.JsonParser
import okhttp3.*

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException
import com.bumptech.glide.Glide

class MainActivity : AppCompatActivity()
{

    private lateinit var buttonApi: Button
    private lateinit var imageViewPrevisao: ImageView
    private lateinit var textViewCondicao : TextView
    private lateinit var textViewTemperatura : TextView

    private var poalat = -30.0346
    private var poalon = -51.2177

    // Método é chamado toda vez que o app abrir
    override fun onCreate(savedInstanceState: Bundle?)
    {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity) // seu XML do layout

        buttonApi = findViewById(R.id.buttonApi)
        imageViewPrevisao = findViewById(R.id.imageViewPrevisao)
        textViewCondicao = findViewById(R.id.textViewCondicao)
        textViewTemperatura = findViewById(R.id.textViewTemperatura)

        buttonApi.setOnClickListener {
            fetchWeather(poalat, poalon)
        }

    }

    fun fetchWeather(poaLat:Double, poaLon:Double)
    {
        // Chave da API
        var apiKey = "fbd2f9ebe81059a86e30de49d62d6b7d"

        //Criar a URL da chamada da API
        val url = "https://api.openweathermap.org/data/2.5/weather?" +
                "lat=$poaLat&lon=$poaLon&appid=$apiKey&units=metric&lang=pt_br"

        // Declarar client/request
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        // Fazer a chamada da API
        client.newCall(request).enqueue(object : Callback {

            // Se deu errado
            override fun onFailure(call: Call, e: IOException)
            {
                runOnUiThread {
                    Toast.makeText(this@MainActivity,"Não consegui consultar o tempo",Toast.LENGTH_SHORT).show()
                }
            }

            // Se deu certo
            override fun onResponse(call: Call, response: Response)
            {
                val body = response.body?.string()
                if (body != null) {
                    val json = JsonParser.parseString(body).asJsonObject
                    val temp = json.getAsJsonObject("main").get("temp").asDouble
                    val condition = json.getAsJsonArray("weather")[0].asJsonObject.get("description").asString
                    runOnUiThread {

                        textViewTemperatura.text = "%.0f °C".format(temp)
                        textViewCondicao.text = condition.toString()
                        when {

                            condition.contains("chuva",true) -> {
                                imageViewPrevisao.setImageResource(R.drawable.rain)
                            }
                            condition.contains("nuvem",true) -> {
                                imageViewPrevisao.setImageResource(R.drawable.cloud)
                            }
                            condition.contains("céu limpo",true) -> {
                                val imgGif: ImageView = findViewById(R.id.imageViewPrevisao)
                                Glide.with(this@MainActivity)
                                    .asGif()
                                    .load(R.drawable.sun2) // ou uma URL: "https://..."
                                    .into(imgGif)
                            }
                            else ->{
                                imageViewPrevisao.setImageResource(R.drawable.weather)
                            }

                        }
                    }
                }
            }

        })


    }

}