package com.ifrs.app

import com.google.gson.JsonParser
import okhttp3.*

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import java.io.IOException

class MainActivity : AppCompatActivity()
{

    private lateinit var btnWeather: Button
    private lateinit var imgWeather: ImageView
    private lateinit var weatherListLayout: LinearLayout

    private val apiKey = "fbd2f9ebe81059a86e30de49d62d6b7d"

    private val poaLat = -30.0277   // Latitude de Porto Alegre
    private val poaLon = -51.2287   // Longitude de Porto Alegre

    // Método é chamado toda vez que o app abrir
    override fun onCreate(savedInstanceState: Bundle?)
    {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity) // seu XML do layout

        btnWeather = findViewById(R.id.btnWeather)
        imgWeather = findViewById(R.id.imgWeather)
        weatherListLayout = findViewById(R.id.weatherListLayout)

    }

}