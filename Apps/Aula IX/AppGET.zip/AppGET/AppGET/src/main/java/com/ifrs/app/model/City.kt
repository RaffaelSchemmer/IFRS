package com.ifrs.app.model

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

// Representa a tabela CITY no banco de dados H2
@Entity
data class City(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) // Chave primária auto-increment
    val id: Long = 0,
    val name: String,  // Nome da cidade
    val country: String, // País da cidade
    val lat: Double,   // Latitude
    val lon: Double    // Longitude
)
