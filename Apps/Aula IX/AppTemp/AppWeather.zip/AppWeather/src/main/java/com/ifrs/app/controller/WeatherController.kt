package com.ifrs.app.controller

import com.ifrs.app.repository.CityRepository
import com.ifrs.app.service.WeatherService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import kotlin.random.Random

// Controlador REST que recebe requisições HTTP
@RestController
class WeatherController(
    private val cityRepository: CityRepository, // Repositório de cidades
    private val weatherService: WeatherService  // Serviço que chama a API
) {

    private val validApiKey = "app123" // ApiKey que o app deve fornecer

    @GetMapping("/weather") // Endpoint GET /weather?apikey=...
    fun getWeather(@RequestParam("apikey") apiKey: String): String {
        if (apiKey != validApiKey) { // Valida ApiKey enviada pelo app
            return """{"error":"ApiKey inválida"}"""
        }

        val cities = cityRepository.findAll() // Busca todas as cidades cadastradas
        val randomCity = cities[Random.nextInt(cities.size)] // Escolhe uma aleatória
        return weatherService.getWeather(randomCity, "fbd2f9ebe81059a86e30de49d62d6b7d") 
        // Retorna JSON da OpenWeatherMap
    }
}
