package com.ifrs.app

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

// Indica que esta é a classe principal do Spring Boot
@SpringBootApplication
class AppWeatherBackendApplication

// Ponto de entrada da aplicação
fun main(args: Array<String>) {
    runApplication<AppWeatherBackendApplication>(*args)
}
