package com.ifrs.app.service

import com.ifrs.app.model.City
import okhttp3.OkHttpClient
import okhttp3.Request
import org.springframework.stereotype.Service
import com.google.gson.JsonParser

// Serviço que faz a consulta da API do OpenWeatherMap
@Service
class WeatherService {

    private val client = OkHttpClient() // Cliente HTTP para fazer GET

    fun getWeather(city: City, apiKey: String): String {
        // Monta a URL com latitude, longitude e API key
        val url =
            "https://api.openweathermap.org/data/2.5/weather?lat=${city.lat}&lon=${city.lon}&appid=$apiKey&units=metric&lang=pt_br"
        val request = Request.Builder().url(url).build()
        
        // Executa a requisição de forma síncrona
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw RuntimeException("Erro na API: ${response.code}")
            }
            return response.body?.string() ?: throw RuntimeException("Resposta vazia")
        }
    }
}
