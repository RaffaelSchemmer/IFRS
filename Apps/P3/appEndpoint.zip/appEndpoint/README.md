
mvn clean install
mvn spring-boot:run

curl -X POST http://localhost:8080/images ^ -F "file=@bitcoin.png"

