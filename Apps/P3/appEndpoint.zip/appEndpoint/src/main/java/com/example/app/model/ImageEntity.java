package com.example.app.model;

public class ImageEntity {
    private Integer id;
    private String nomeOriginal;
    private String hash;
    private long timestamp;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNomeOriginal() { return nomeOriginal; }
    public void setNomeOriginal(String nomeOriginal) { this.nomeOriginal = nomeOriginal; }

    public String getHash() { return hash; }
    public void setHash(String hash) { this.hash = hash; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
