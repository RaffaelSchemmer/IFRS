package com.example.app.model;

import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ImageRepository {

    private final ImageDAO dao;

    public ImageRepository() {
        this.dao = new ImageDAO("jdbc:sqlite:images.db");
    }

    public boolean save(ImageEntity img) {
        return dao.insert(img);
    }

    public List<ImageEntity> findAll() {
        return dao.findAll();
    }
}
