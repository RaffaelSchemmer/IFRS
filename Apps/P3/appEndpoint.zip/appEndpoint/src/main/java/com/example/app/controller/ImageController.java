package com.example.app.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.app.model.*;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

@RestController
@RequestMapping("/images")
public class ImageController {

    private final ImageRepository repo;

    private final Path uploadDir = Paths.get("upload");

    public ImageController(ImageRepository repo) throws Exception {
        this.repo = repo;

        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }
    }

    // ------------ POST: upload imagem ------------
    @PostMapping(consumes = "multipart/form-data")
    public Map<String,Object> upload(@RequestParam("file") MultipartFile file) {

        try {
            String nomeOriginal = file.getOriginalFilename();
            long timestamp = System.currentTimeMillis();

            // hash: SHA-256 + timestamp para garantir unicidade
            String hash = gerarHash(file.getBytes(), timestamp);

            Path destino = uploadDir.resolve(hash);
            Files.write(destino, file.getBytes());

            ImageEntity ent = new ImageEntity();
            ent.setNomeOriginal(nomeOriginal);
            ent.setHash(hash);
            ent.setTimestamp(timestamp);

            boolean ok = repo.save(ent);

            return Map.of(
                "success", ok,
                "hash", hash,
                "nomeOriginal", nomeOriginal
            );

        } catch (Exception e){
            e.printStackTrace();
            return Map.of("success", false);
        }
    }

    private String gerarHash(byte[] data, long ts) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(data);
        md.update(Long.toString(ts).getBytes());
        byte[] digest = md.digest();

        StringBuilder sb = new StringBuilder();
        for(byte b : digest){
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // ------------ GET: retorna arquivo físico ------------
    @GetMapping("/file/{hash}")
    public byte[] getFile(@PathVariable String hash) throws Exception {
        Path arq = uploadDir.resolve(hash);
        return Files.readAllBytes(arq);
    }

    // ------------ GET: HTML com imagens ------------
    @GetMapping(value = "/html", produces = "text/html")
    public String listAsHtml() {

        StringBuilder html = new StringBuilder("""
            <html>
            <head>
                <meta charset='UTF-8'>
                <title>Lista de Imagens</title>
                <style>
                    body { font-family: Arial; padding: 20px; }
                    img { max-width: 250px; border-radius: 8px; margin: 10px 0; }
                </style>
            </head>
            <body>
                <h1>Imagens cadastradas</h1>
                <ul>
        """);

        for (ImageEntity img : repo.findAll()) {

            String fileUrl = "/images/file/" + img.getHash();

            html.append("<li>")
                .append("<b>").append(img.getNomeOriginal()).append("</b><br>")
                .append("<img src='").append(fileUrl).append("' />")
                .append("<br>Hash: ").append(img.getHash())
                .append("</li>");
        }

        html.append("""
                </ul>
            </body>
            </html>
        """);

        return html.toString();
    }
}
