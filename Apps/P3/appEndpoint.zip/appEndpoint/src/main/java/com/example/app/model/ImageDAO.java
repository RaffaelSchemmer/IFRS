package com.example.app.model;

import java.sql.*;
import java.util.*;

public class ImageDAO {

    private final String url;

    public ImageDAO(String url){
        this.url = url;
        criarTabela();
    }

    private void criarTabela() {
        String sql = """
            CREATE TABLE IF NOT EXISTS images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_original TEXT NOT NULL,
                hash TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            );
        """;

        try (Connection conn = DriverManager.getConnection(url);
             Statement st = conn.createStatement()) {
            st.execute(sql);
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public boolean insert(ImageEntity e){
        String sql = "INSERT INTO images(nome_original, hash, timestamp) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement st = conn.prepareStatement(sql)) {

            st.setString(1, e.getNomeOriginal());
            st.setString(2, e.getHash());
            st.setLong(3, e.getTimestamp());

            st.executeUpdate();
            return true;

        } catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
    }

    public List<ImageEntity> findAll(){
        List<ImageEntity> list = new ArrayList<>();

        String sql = "SELECT id, nome_original, hash, timestamp FROM images";

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement st = conn.prepareStatement(sql);
             ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                ImageEntity e = new ImageEntity();
                e.setId(rs.getInt("id"));
                e.setNomeOriginal(rs.getString("nome_original"));
                e.setHash(rs.getString("hash"));
                e.setTimestamp(rs.getLong("timestamp"));
                list.add(e);
            }

        } catch(Exception ex){
            ex.printStackTrace();
        }

        return list;
    }
}
