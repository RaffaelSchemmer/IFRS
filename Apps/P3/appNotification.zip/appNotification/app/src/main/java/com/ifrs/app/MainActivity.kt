package com.ifrs.app

// Importações necessárias para criar notificações
import android.app.NotificationChannel
import android.app.NotificationManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Build
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    // ID único do canal de notificação (obrigatório no Android 8+)
    private val channelId = "weather_channel"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)  // Carrega o layout XML da tela

        // Solicita permissão para enviar notificações no Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001)
        }

        // Cria o canal de notificação (necessário no Android 8+)
        createNotificationChannel()

        // Pega o ImageView do XML (imagem clicável)
        val btn = findViewById<ImageView>(R.id.btnCenter)

        // Quando o usuário clicar na imagem, gera uma notificação
        btn.setOnClickListener {
            showNotification()
        }
    }

    private fun showNotification() {

        // Builder que cria a notificação
        val builder = NotificationCompat.Builder(this, channelId)
            // ÍCONE pequeno (aparece na barra de status)
            .setSmallIcon(R.drawable.apple)

            // Título da notificação
            .setContentTitle("Fruta do Dia")

            // Texto principal interno da notificação
            .setContentText("Sua maçã está pronta para ser consumida!")

            // Prioridade NORMAL
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

            // ÍCONE grande (dentro da notificação)
            .setLargeIcon(
                BitmapFactory.decodeResource(
                    resources,
                    R.drawable.apple
                )
            )

        // Envia a notificação
        // Usando System.currentTimeMillis para garantir ID único sempre
        with(NotificationManagerCompat.from(this)) {
            notify(System.currentTimeMillis().toInt(), builder.build())
        }
    }

    private fun createNotificationChannel() {

        // Canal é obrigatório apenas no Android 8 (Oreo) e acima
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            // Nome e descrição do canal (visível ao usuário)
            val name = "Canal Simples"
            val descriptionText = "Canal para notificações básicas"

            // Importância: controla como "forte" a notificação é
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            // Cria o canal com ID, nome e importância
            val channel = NotificationChannel(channelId, name, importance)
            channel.description = descriptionText

            // Registra o canal no sistema Android
            val notificationManager =
                getSystemService(NotificationManager::class.java)

            notificationManager.createNotificationChannel(channel)
        }
    }
}
