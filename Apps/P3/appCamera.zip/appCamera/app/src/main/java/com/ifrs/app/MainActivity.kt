package com.example.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.os.*
import android.util.Log
import android.view.TextureView
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.Executors
import com.ifrs.app.R

class MainActivity : AppCompatActivity() {

    // Componentes da UI
    private lateinit var textureView: TextureView      // Preview da câmera
    private lateinit var fabCapture: FloatingActionButton // Botão de captura
    private lateinit var fabFlash: FloatingActionButton   // Botão de ligar/desligar flash
    private lateinit var flashView: View                  // View transparente para piscada verde/vermelha

    // Variáveis da câmera
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var requestBuilder: CaptureRequest.Builder? = null
    private var flashOn = false

    // Outros
    private val cameraManager by lazy { getSystemService(CAMERA_SERVICE) as CameraManager } // gerenciador da câmera
    private val executor = Executors.newSingleThreadExecutor() // executor para tarefas em background
    private val client = OkHttpClient() // cliente HTTP para upload

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        // Inicializa componentes da UI
        textureView = findViewById(R.id.textureView)
        fabCapture = findViewById(R.id.fabCapture)
        fabFlash = findViewById(R.id.fabFlash)
        flashView = findViewById(R.id.flashView)

        // Listener do TextureView para iniciar a câmera quando estiver pronto
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                openCamera() // abre a câmera quando a superfície estiver disponível
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }

        // Botão de flash
        fabFlash.setOnClickListener { toggleFlash() }

        // Botão de captura
        fabCapture.setOnClickListener { captureAndSend() }
    }

    // ---------- Abrir câmera ----------
    private fun openCamera() {
        val cameraId = cameraManager.cameraIdList[0] // usa a primeira câmera
        // Verifica permissão de câmera
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
            return
        }
        // Abre a câmera
        cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraDevice = camera
                startPreview() // inicia preview quando câmera aberta
            }
            override fun onDisconnected(camera: CameraDevice) { camera.close() } // desconectou
            override fun onError(camera: CameraDevice, error: Int) { camera.close() } // erro
        }, null)
    }

    // ---------- Inicia preview da câmera ----------
    private fun startPreview() {
        val texture = textureView.surfaceTexture ?: return
        texture.setDefaultBufferSize(640, 480) // tamanho do buffer
        val surface = android.view.Surface(texture)
        requestBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        requestBuilder?.addTarget(surface)
        // Cria sessão de captura
        cameraDevice?.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                requestBuilder?.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                session.setRepeatingRequest(requestBuilder!!.build(), null, null) // inicia preview contínuo
            }
            override fun onConfigureFailed(session: CameraCaptureSession) {}
        }, null)
    }

    // ---------- Liga/desliga flash ----------
    private fun toggleFlash() {
        flashOn = !flashOn
        requestBuilder?.set(CaptureRequest.FLASH_MODE,
            if (flashOn) CameraMetadata.FLASH_MODE_TORCH else CameraMetadata.FLASH_MODE_OFF)
        captureSession?.setRepeatingRequest(requestBuilder!!.build(), null, null)
        fabFlash.setColorFilter(if (flashOn) 0xFFFFD700.toInt() else 0xFF000000.toInt()) // dourado/black
    }

    // ---------- Bloqueia UI durante upload ----------
    private fun lockUI() {
        fabCapture.isEnabled = false          // desativa botão de captura
        captureSession?.stopRepeating()       // pausa preview
    }

    // ---------- Desbloqueia UI após upload ----------
    private fun unlockUI() {
        fabCapture.isEnabled = true
        requestBuilder?.let { captureSession?.setRepeatingRequest(it.build(), null, null) } // retoma preview
    }

    // ---------- Captura imagem e envia para o servidor ----------
    private fun captureAndSend() {
        textureView.bitmap?.let { bitmap ->
            lockUI() // bloqueia UI

            // Salva bitmap em arquivo temporário
            val file = File(cacheDir, "capture.png")
            FileOutputStream(file).use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }

            // Cria corpo da requisição multipart
            val requestBody = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", "capture.png", file.asRequestBody("image/png".toMediaType()))
                .build()

            val request = Request.Builder()
                .url("http://172.31.32.99:8080/images") // URL do servidor
                .post(requestBody)
                .build()

            // Envia requisição de forma assíncrona
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        showToast("Falha ao enviar")
                        flashScreen(false) // piscada vermelha
                        Log.d("Upload", "Falha ao enviar: ${e.message}")
                        unlockUI() // desbloqueia UI
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    runOnUiThread {
                        showToast("Imagem salva na nuvem")
                        flashScreen(true) // piscada verde
                        unlockUI() // desbloqueia UI
                    }
                }
            })
        }
    }

    // ---------- Pisca a tela verde ou vermelha ----------
    private fun flashScreen(success: Boolean) {
        flashView.setBackgroundColor(
            if (success) 0x8800FF00.toInt() // verde semitransparente
            else 0x88FF0000.toInt()       // vermelho semitransparente
        )
        flashView.alpha = 0f
        flashView.visibility = View.VISIBLE
        flashView.animate()
            .alpha(1f)
            .setDuration(100)
            .withEndAction {
                flashView.animate()
                    .alpha(0f)
                    .setDuration(100)
                    .withEndAction { flashView.visibility = View.GONE }
            }
    }

    // ---------- Mostra toast customizado ----------
    private fun showToast(msg: String) {
        val toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT)
        toast.setGravity(android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL, 0, -500)
        toast.show()
    }
}
