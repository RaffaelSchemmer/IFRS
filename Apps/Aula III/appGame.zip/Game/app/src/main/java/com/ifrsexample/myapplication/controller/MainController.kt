package com.ifrsexample.myapplication.controller

import android.content.Context
import android.graphics.Color
import android.widget.Toast

class MainController(private val context: Context) {
    var contador = 0

    fun incrementar(): Int {

        contador++

        if (contador == 5 || contador == 10)
        {
            Toast.makeText(context, "Contador chegou a $contador", Toast.LENGTH_SHORT).show()
        }
        return contador
    }

    fun decrementar(): Int {

        if(contador > 0)
            contador--

        return contador
    }
}