package com.ifrsexample.myapplication.controller

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.ifrsexample.myapplication.R

class MainActivity : AppCompatActivity() {

    private lateinit var controller: MainController

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        setContentView(R.layout.activity_main)
        controller = MainController(this)

        val textViewContador = findViewById<TextView>(R.id.textViewContador)
        val botaoIncrementar = findViewById<Button>(R.id.botaoIncrementar)
        val buttonDecrementar = findViewById<Button>(R.id.botaoDecrementar)

        botaoIncrementar.setOnClickListener {
            val novoValor = controller.incrementar()
            textViewContador.text = novoValor.toString()
        }


        buttonDecrementar.setOnClickListener {
            val novoValor = controller.decrementar()
            textViewContador.text = novoValor.toString()
        }

    }
}