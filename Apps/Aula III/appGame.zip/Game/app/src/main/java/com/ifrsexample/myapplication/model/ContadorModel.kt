package com.ifrsexample.myapplication.controller

class ContadorModel {
    // Será preenchido posteriormente
}