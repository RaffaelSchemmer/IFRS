package com.ifrs.app

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.ImageView
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var minhaImagem: ImageView
    private lateinit var meuSwitch: Switch

    private var mediaPlayer: MediaPlayer? = null
    private var contadorToast = 1
    private var anguloAtual = 0f

    private lateinit var vibrator: Vibrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        minhaImagem = findViewById(R.id.minhaImagem)
        meuSwitch = findViewById(R.id.meuSwitch)

        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        // Som inicial
        tocarSom(R.raw.windows)

        // ==========================
        // Clique na imagem
        // ==========================
        minhaImagem.setOnClickListener {

            // gira 5 graus
            anguloAtual += 5f
            if (anguloAtual >= 360f) anguloAtual -= 360f
            minhaImagem.rotation = anguloAtual

            // Toast contador
            Toast.makeText(this, contadorToast.toString(), Toast.LENGTH_SHORT).show()
            contadorToast++

            // Vibração curta a cada clique
            vibrarCurto()
            tocarSom(R.raw.duck)
            // Som 1UP + vibração longa ao atingir 90°
            if (anguloAtual % 360f == 45f) {
                tocarSom(R.raw.life)
                vibrarLongo()
                Thread.sleep(300)
            }
        }

        // ==========================
        // Clique no switch
        // ==========================
        meuSwitch.setOnCheckedChangeListener { _, _ ->
            tocarSom(R.raw.jump)
            vibrarCurto()
        }
    }

    // ===========================
    // Funções de áudio
    // ===========================
    fun tocarSom(resId: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resId)
        mediaPlayer?.start()
    }

    fun pausarSom() {
        if (mediaPlayer?.isPlaying == true) mediaPlayer?.pause()
    }

    fun continuarSom() {
        if (mediaPlayer != null && mediaPlayer?.isPlaying == false) mediaPlayer?.start()
    }

    fun pararSom() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    // ===========================
    // Funções de vibração
    // ===========================
    private fun vibrarCurto() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(50)
        }
    }

    private fun vibrarLongo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pararSom()
    }
}
