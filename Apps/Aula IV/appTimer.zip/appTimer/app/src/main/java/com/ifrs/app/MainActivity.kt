package com.ifrs.app

import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

class MainActivity : AppCompatActivity() {

    private lateinit var meuBotao: ImageButton
    private lateinit var meuTimer: EditText
    private lateinit var vibrator: Vibrator

    private var contadorToast = 1
    private var anguloAtual = 0f

    private var mediaPlayer: MediaPlayer? = null
    private var countDownTimer: CountDownTimer? = null
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        // Referências
        meuBotao = findViewById(R.id.startButton)
        meuTimer = findViewById(R.id.timerEditText)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        meuTimer.doAfterTextChanged { editable ->
            val texto = editable.toString()

            // Remove tudo que não seja número
            val numeros = texto.replace(Regex("[^0-9]"), "")

            // Limita a no máximo 4 dígitos (MMSS)
            val limitado = if (numeros.length > 4) numeros.substring(0, 4) else numeros

            val minutos =
                if (limitado.length >= 3) limitado.substring(0, limitado.length - 2) else "0"
            val segundos = if (limitado.length >= 2) limitado.takeLast(2) else limitado

            val minutosInt = minutos.toIntOrNull()?.coerceIn(0, 59) ?: 0
            val segundosInt = segundos.toIntOrNull()?.coerceIn(0, 59) ?: 0

            val formatado = String.format("%02d:%02d", minutosInt, segundosInt)

            if (formatado != texto) {
                meuTimer.setText(formatado)
                meuTimer.setSelection(formatado.length)
            }
        }

        meuBotao.setOnClickListener {
            if (!isRunning) {
                // Iniciar timer
                val totalMillis = parseTimeToMillis(meuTimer.text.toString())
                if (totalMillis > 0) {
                    startTimer(totalMillis, vibrator)
                    meuTimer.isEnabled = false
                    meuBotao.setImageResource(R.drawable.stop) // muda icone
                    isRunning = true
                }
            } else {
                // Parar timer
                countDownTimer?.cancel()
                meuTimer.isEnabled = true
                meuBotao.setImageResource(R.drawable.play)
                isRunning = false
            }
        }

    }

    private fun parseTimeToMillis(time: String): Long {
        // Espera formato MM:SS
        val parts = time.split(":")
        val minutes = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val seconds = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return ((minutes * 60) + seconds) * 1000L
    }

    private fun startTimer(millis: Long, vibrator: Vibrator) {
        countDownTimer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val totalSeconds = millisUntilFinished / 1000
                val minutes = totalSeconds / 60
                val seconds = totalSeconds % 60
                meuTimer.setText(String.format("%02d:%02d", minutes, seconds))

                // Vibração 250ms a cada tick
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(250)
                    tocarSom(R.raw.duck)
                }
            }

            override fun onFinish() {
                tocarSom(R.raw.windows)
                meuTimer.setText("00:00")
                meuBotao.setImageResource(R.drawable.play)
                meuTimer.isEnabled = true
                isRunning = false
            }
        }.start()
    }
	
    // Função para tocar som
    private fun tocarSom(resId: Int) {
        // Libera o MediaPlayer anterior
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resId)
        mediaPlayer?.start()
    }

}
