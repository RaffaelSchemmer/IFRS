package com.example.contadorapp.model

class ContadorModel {
    // Será preenchido posteriormente
}