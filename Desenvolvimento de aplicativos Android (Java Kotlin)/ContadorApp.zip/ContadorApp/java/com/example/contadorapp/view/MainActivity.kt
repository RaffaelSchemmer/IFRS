package com.example.contadorapp.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.contadorapp.R
import com.example.contadorapp.controller.MainController
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var controller: MainController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        controller = MainController(this)

        buttonIncrementar.setOnClickListener {
            val novoValor = controller.incrementar()
            textViewContador.text = novoValor.toString()
        }

        buttonDecrementar.setOnClickListener {
            val novoValor = controller.decrementar()
            textViewContador.text = novoValor.toString()
        }
    }
}