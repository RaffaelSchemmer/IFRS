import android.content.Context

class UsuarioController(private val context: Context) {
    private val model = UsuarioModel(context)

    fun autenticar(username: String, password: String): Boolean {
        return model.validarUsuario(username, password)
    }
}
