package com.ifrsexample.myapplication.view

import UsuarioController
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import com.ifrsexample.myapplication.R

class MainActivity : AppCompatActivity() {
    private lateinit var controller: UsuarioController
    private lateinit var progressBar: ProgressBar
    private lateinit var btnLogin: Button
    private lateinit var edtUser: EditText
    private lateinit var edtPass: EditText

    fun showKeyboard(editText: EditText) {
        editText.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(editText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        controller = UsuarioController(this)

        edtUser = findViewById(R.id.edtUser)
        edtPass = findViewById(R.id.edtPass)
        btnLogin = findViewById(R.id.btnLogin)
        progressBar = findViewById(R.id.progressBar)

        btnLogin.isEnabled = false
        progressBar.visibility = View.INVISIBLE

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                btnLogin.isEnabled = edtUser.text.isNotEmpty() && edtPass.text.isNotEmpty()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        edtUser.addTextChangedListener(watcher)
        edtPass.addTextChangedListener(watcher)

        btnLogin.setOnClickListener {
            val username = edtUser.text.toString()
            val password = edtPass.text.toString()

            progressBar.visibility = View.VISIBLE
            btnLogin.isEnabled = false

            Handler(Looper.getMainLooper()).postDelayed({
                progressBar.visibility = View.INVISIBLE
                btnLogin.isEnabled = true

                if (controller.autenticar(username, password)) {
                    val intent = Intent(this, SegundaActivity::class.java)
                    val options = ActivityOptionsCompat.makeCustomAnimation(
                        this,
                        android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right
                    )
                    startActivity(intent, options.toBundle())
                } else {
                    Toast.makeText(this, "Login e/ou senha incorretos", Toast.LENGTH_SHORT).show()
                }
            }, 3000)
        }
    }
}
