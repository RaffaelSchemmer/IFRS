package com.ifrsexample.myapplication.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ifrsexample.myapplication.R

class SegundaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda)
        supportActionBar?.hide()
    }
}
